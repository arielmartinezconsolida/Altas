<?php namespace App\Entities;
class Province
{

}