<?php namespace App\Entities;
class Work_place
{

}