<?php namespace App\Entities;
class Roadtype
{

}