<?php namespace App\Entities;
class Company_agreement
{

}