<?php namespace App\Entities;
class Category
{

}