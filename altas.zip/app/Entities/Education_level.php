<?php namespace App\Entities;
class Education_level
{

}