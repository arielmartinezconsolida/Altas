<?php namespace App\Entities;
class User
{

}