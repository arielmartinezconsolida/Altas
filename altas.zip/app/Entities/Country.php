<?php namespace App\Entities;
class Country
{

}