<?php namespace App\Entities;
class Municipality
{

}