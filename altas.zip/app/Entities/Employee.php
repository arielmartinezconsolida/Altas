<?php namespace App\Entities;
class Employee
{

}