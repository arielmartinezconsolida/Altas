<?php namespace App\Entities;
class Cno_level_1
{

}